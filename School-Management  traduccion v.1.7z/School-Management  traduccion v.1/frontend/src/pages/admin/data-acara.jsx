import React from "react";

const DataAcaraPage = () => {
  return <div>DataAcaraPage</div>;
};

export default DataAcaraPage;
